/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'ku', {
	pathName: 'ڕاگەیاندنی بەرکار',
	title: 'خستنەناوی ڕاگەیاندن',
	button: 'خستنەناوی ڕاگەیاندن',
	unsupportedUrlGiven: 'بەستەری نیشانکراو پشتیوان نەکراوە.',
	unsupportedUrl: 'بەستەری {url} پشتیواننەککراوە لەلایەن خستنەناوی ڕاگەیاندن.',
	fetchingFailedGiven: 'سەرکەوتوونەبوو لە هێنانی ناوەڕۆکی بەستەری دراو',
	fetchingFailed: 'سەرکەوتوونەبوو لە هێنانەی ناوەڕۆکی ئەم بەستەرە {url}.',
	fetchingOne: 'لە هەوڵی وەڵامی خستنەناوە',
	fetchingMany: 'لە هەوڵی هێنانی خستنەناوە, {current} لە {max} کۆتایهاتووە...'
} );
